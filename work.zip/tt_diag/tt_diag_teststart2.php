<!DOCTYPE html>
<html lang="ko" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./css/tt_diag.css">
    <title></title>
  </head>
  <body>
    <div class="">
      <img src="./img/list3.png" alt="">
    </div>
    <div class="btn_center">
      <a href="tt_diag_list3.php">다음</a>
      <a href="tt_diag_list2.php">이전</a>
    </div>
  </body>
</html>
